﻿using System;

class Program 
{
    static void Main(string[] args)
    {
        Console.WriteLine("Laboratorio 07 - Sofia Paiz - 1092224");
        int NFibonacci;
        bool conversion = false;
        bool nPositivo = true;

        do
        {
            Console.WriteLine("Ingrese un número mayor a 0");
            conversion = int.TryParse(Console.ReadLine(), out NFibonacci);
            if (conversion)
            {
                if (NFibonacci > 0)
                {
                    nPositivo = true;
                }
            }
        } while (!conversion || !nPositivo);

      
        int a = 0;
        int b = 1;
        int c;

        Console.Write("{0} {1} ", a, b);

        int i = 2;
        while (i < NFibonacci)
        {
            c = a + b;
            Console.Write("{0} ", c);
            a = b;
            b = c;
            i++;
        }
       SerieA(NFibonacci);
        SerieB(NFibonacci);
        SerieC();
    }

    static void SerieA(int N)
    {
        double resultado = 0;
        int i = 1;
        while (i <= N)
        {
            resultado += 1.0 / i;
            i++;
        }
        Console.WriteLine("Serie A: " + resultado);
    }

    static void SerieB(int N)
    {
        double resultado = 0;
        int i = 1;
        while (i <= N)
        {
            resultado += 1.0 / Math.Pow(2, i);
            i++;
        }
        Console.WriteLine("Serie B: " + resultado);
    }

    static void SerieC()
    {
        Console.WriteLine("Ingrese el valor de x:");
        int x = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Ingrese el valor de a:");
        int a = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Ingrese el valor de n:");
        int n = Convert.ToInt32(Console.ReadLine());

        double resultado = 0;
        int k = 0;
        while (k <= n)
        {
            resultado += Math.Pow(x, k) * Math.Pow(a, (n - k));
            k++;
        }
        Console.WriteLine("Serie C: " + resultado);
    }
}

        
       